/*
*           Custom code javaScript
*           Место для твоего кода  
*/

$(function() {  
    //  Анимация подъема наверх (плавный)
    $('#up').click(function() {
		$('html, body').animate({
			scrollTop: $('header').offset().top 
		}, 1000);
    });
    //  Анимация спуск вниз (плавный)
    $('.button-down').click(function() {
		$('html, body').animate({
			scrollTop: $('.about_header').offset().top 
		}, 1000);
    });
    
    //  Анимация - появление объектов в процессе прокрутки страницы.
    $('.content, .portfolio_item, .about_item, .form, .info')
        .css('opacity','0')
        .animateScroll({
            classToAdd: 'animated fadeIn',            
            offset: 100,
        });

    //  Парралакс
    $('.masthead').each(function() {
        var o = {                
            offset:     5,      //	задаем на какую величину подвинуть фон 5-ка указывает на то что
                                //	фон будет в 5 раз медленнее двигатся чем прокрутка документа                
            leftBg:       '50%',  //  Позиция фона по оси x
            topBg:      95,                                
            obj:        $(this),                
        }
        o.topElm =      o.obj.offset().top;            
        o.heightWin =   $(window).innerHeight();
        o.delta = o.topElm < o.heightWin ?  o.topBg/o.offset : 0 ;            
        o.obj.css({
            backgroundAttachment: 'fixed',
            backgroundPosition: '50% '+ o.topBg+'px',});
            
        //		событие движения скролла
        $(window).scroll(function() { 
                        
            var topWin = $(window).scrollTop();
            
            // 		Условия таковы что если страница приблизится к началу появления
            //		блока в селекторе то выполнить преобразования позиции фона
            if( topWin > (o.topElm - o.heightWin) ) {
                
                var offset = (topWin - o.topBg)/o.offset + o.delta;                        
                var coords = o.leftBg + ' ' + (o.topBg - offset) + 'px';
                
                o.obj.css({backgroundPosition: coords});
            }
        });
        //		событие в случае изменения размеров экрана 
        //		записывает координаты элемента 
        $(window).resize(function() {
            o.topElm =      o.obj.offset().top;
            o.heightWin =   $(window).innerHeight();
        });
    });
    
    /*
    *       ---------------------
    *           work form
    *       -------------------
    */
    $('#feedback').submit(function() {
        //preventDefault();
        $('#submit').val('send...');
        
        $.ajax({
            type: 'POST',
            url:  'feedback.php',
            data: $('#feedback').serialize(),
            success: function(data) {
                if (data === 'true') {
                    $('.message_send p').text('Письмо отправлено. Спасибо!');
                    show_hidden_window();
                } else if (data === 'false') {
                    $('.message_send p').text('Письмо не получилось отправить. Попробуйте еще!');
                    show_hidden_window();
                }

                function show_hidden_window () {
                    $('.message_send').removeClass('flipOutY').addClass('animated flipInY');                    
                    setTimeout(hidden, 8000);   
                }                
                $('#submit').val('submit');
            }
        })
        return false;
    })

    /*
    *       Событие клика на кнопку во всплывающем сообщении.
    */
    $('#ok_send').on('click', function(event){
        hidden();
        return false;
    })
    function hidden() {
        $('.message_send').removeClass('flipInY').addClass('flipOutY');                    
    }
    
});